-- 06_vistas.sql
-- Vista de control de pólizas próximas a vencer

CREATE OR REPLACE VIEW vista_seguro_vencimiento AS
SELECT 
  v.dominio,
  v.marca,
  v.modelo,
  s.nroPoliza,
  s.vencimiento,
  DATEDIFF(s.vencimiento, CURDATE()) AS dias_restantes
FROM Vehiculo v
JOIN SeguroVehicular s ON v.seguro_id = s.id
WHERE s.vencimiento BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 60 DAY)
ORDER BY s.vencimiento ASC;