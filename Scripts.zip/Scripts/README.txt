Trabajo Final Integrador - Bases de Datos I

NTEGRANTES: TADEO OSCAR ACOSTA, DANIEL ALFREDO OSCAR ALDERETE, NAZARENO ARANDA, JULIAN BLANCO CORTÉS.

Descripción: 
Implementación de un modelo relacional (basado en el CRUD de Programación) incluyendo definición de constraints, carga masiva de datos, optimización con índices, consultas avanzadas, seguridad, transacciones y concurrencia.

Entorno y Versión:
SGBD Utilizado: MySQL

Versión del SGBD: MySQL 8.0.34

Motor de Almacenamiento: InnoDB 


Se recomienda la ejecución de los scripts en el siguiente orden secuencial:

1.,01_esquema.sql, Modelado y Definición de Constraints (Creación de tablas, PK, FK, UNIQUE, CHECK). 
2.,02_catalogos.sql, Creación de tablas maestras o catálogos (si aplica).
3.,03_carga_masiva.sql, Generación y Carga Masiva (Inserción de datos de prueba, idealmente entre 10.000 y 500.000 registros). 
4.,04_indices.sql, Creación de Índices adicionales para optimización de consultas.
5.,05_consultas.sql, Definición de Consultas avanzadas (JOIN, GROUP BY, Subconsultas). 
6.,05_explain.sql, Análisis de Performance (Incluye los EXPLAIN para las consultas del paso 5 con y sin índices).
7.,06_vistas.sql, Creación de Vistas útiles y para ocultar información sensible. 
8.,07_seguridad.sql, Seguridad (Creación de usuario con mínimos privilegios y asignación de permisos a vistas y tablas). 
9.,08_transacciones.sql, Transacciones (Ejemplos de START TRANSACTION, COMMIT, ROLLBACK y manejo de errores/logging). 
10.,09_concurrencia_guiada.sql, concurrencia (Scripts para simular bloqueos, deadlocks y pruebas de niveles de aislamiento). 

