-- 07_seguridad.sql
-- Creación de usuario con privilegios mínimos

-- Crear usuario (ajustá la contraseña)
CREATE USER IF NOT EXISTS 'usuario_consulta'@'localhost' IDENTIFIED BY '12345';

-- Revocar todos los privilegios previos (por seguridad)
REVOKE ALL PRIVILEGES, GRANT OPTION FROM 'usuario_consulta'@'localhost';

-- Otorgar permisos mínimos (solo lectura sobre vistas)
GRANT SELECT ON Vehiculo TO 'usuario_consulta'@'localhost';
GRANT SELECT ON SeguroVehicular TO 'usuario_consulta'@'localhost';
GRANT SELECT ON vista_seguro_vencimiento TO 'usuario_consulta'@'localhost';

-- Aplicar cambios
FLUSH PRIVILEGES;
