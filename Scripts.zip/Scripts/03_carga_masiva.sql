-- 03_carga_masiva.sql
-- Carga masiva de datos para el TFI Bases de Datos I
-- Autor: [tu nombre]
-- Idempotente y compatible con MySQL

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_SAFE_UPDATES = 0;
DELETE FROM Vehiculo;
DELETE FROM SeguroVehicular;

SET FOREIGN_KEY_CHECKS = 1;

-- 1️⃣ Carga masiva de seguros
INSERT INTO SeguroVehicular (aseguradora, nroPoliza, cobertura, vencimiento)
SELECT
  CONCAT('Aseguradora_', LPAD(n, 4, '0')),
  CONCAT('POL', LPAD(n, 6, '0')),
  ELT(FLOOR(1 + (RAND() * 3)), 'RC', 'TERCEROS', 'TODO_RIESGO'),
  DATE_ADD(CURDATE(), INTERVAL (RAND() * 730) DAY)
FROM (
  SELECT @rownum := @rownum + 1 AS n
  FROM (SELECT 0 UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3
        UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6
        UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a,
       (SELECT 0 UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3
        UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6
        UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) b,
       (SELECT 0 UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3
        UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6
        UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) c,
       (SELECT @rownum := 0) r
) x
LIMIT 5000;

-- 2️⃣ Carga masiva de vehículos vinculados a seguros
INSERT INTO Vehiculo (dominio, marca, modelo, anio, nroChasis, seguro_id)
SELECT
  CONCAT('DOM', LPAD(id, 6, '0')),
  ELT(FLOOR(1 + (RAND() * 5)), 'Toyota', 'Ford', 'Chevrolet', 'Honda', 'Fiat'),
  ELT(FLOOR(1 + (RAND() * 5)), 'Corolla', 'Focus', 'Onix', 'Civic', 'Cronos'),
  FLOOR(2000 + (RAND() * 24)),
  CONCAT('CHASIS', LPAD(id, 6, '0')),
  id
FROM SeguroVehicular
LIMIT 5000;
