-- 01_esquema.sql
-- Script idempotente para MySQL: crea las tablas SeguroVehicular y Vehiculo

DROP TABLE IF EXISTS Vehiculo;
DROP TABLE IF EXISTS SeguroVehicular;

CREATE TABLE SeguroVehicular (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  eliminado BOOLEAN NOT NULL DEFAULT FALSE, -- baja lógica
  aseguradora VARCHAR(80) NOT NULL,
  nroPoliza VARCHAR(50) NOT NULL,
  cobertura ENUM('RC','TERCEROS','TODO_RIESGO') NOT NULL,
  vencimiento DATE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE (nroPoliza)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE Vehiculo (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  eliminado BOOLEAN NOT NULL DEFAULT FALSE,
  dominio VARCHAR(10) NOT NULL,
  marca VARCHAR(50) NOT NULL,
  modelo VARCHAR(50) NOT NULL,
  anio INT,
  nroChasis VARCHAR(50),
  seguro_id BIGINT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE (dominio),
  UNIQUE (nroChasis),
  CONSTRAINT fk_vehiculo_seguro FOREIGN KEY (seguro_id) REFERENCES SeguroVehicular(id)
    ON DELETE SET NULL
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Inserciones válidas
INSERT INTO SeguroVehicular (aseguradora, nroPoliza, cobertura, vencimiento)
VALUES ('La Buena Aseguradora', 'POL123456', 'TODO_RIESGO', '2026-12-31');

INSERT INTO Vehiculo (dominio, marca, modelo, anio, nroChasis, seguro_id)
VALUES ('ABC123', 'Toyota', 'Corolla', 2019, 'CHASIS0001', 1);
-- Intento duplicar dominio -> debe fallar por UNIQUE
INSERT INTO Vehiculo (dominio, marca, modelo)
VALUES ('ABC123', 'Ford', 'Focus');
-- Referencia a seguro inexistente -> debe fallar por FK
INSERT INTO Vehiculo (dominio, marca, modelo, seguro_id)
VALUES ('XYZ999', 'Chevrolet', 'Onix', 999999);
