-- 05_consultas.sql
-- Consultas complejas y útiles del sistema Vehículo–SeguroVehicular

-- 1️⃣ Consulta JOIN (igualdad)
-- Vehículos y sus seguros (JOIN 1:1)
SELECT v.dominio, v.marca, v.modelo, s.nroPoliza, s.cobertura
FROM Vehiculo v
JOIN SeguroVehicular s ON v.seguro_id = s.id
WHERE v.marca = 'Toyota' AND v.modelo = 'Corolla';

-- 2️⃣ Consulta JOIN + RANGO
-- Vehículos con pólizas próximas a vencer (rango temporal)
SELECT v.dominio, v.marca, s.vencimiento
FROM Vehiculo v
JOIN SeguroVehicular s ON v.seguro_id = s.id
WHERE s.vencimiento BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY);

-- 3️⃣ Consulta con GROUP BY + HAVING
-- Marcas con más de 800 vehículos registrados
SELECT marca, COUNT(*) AS cantidad
FROM Vehiculo
GROUP BY marca
HAVING COUNT(*) > 800
ORDER BY cantidad DESC;

-- 4️⃣ Consulta con SUBCONSULTA
-- Vehículos cuyo seguro vence el mismo día que el seguro más próximo a vencer
SELECT dominio, marca, modelo, seguro_id
FROM Vehiculo
WHERE seguro_id IN (
    SELECT id
    FROM SeguroVehicular
    WHERE vencimiento = (SELECT MIN(vencimiento) FROM SeguroVehicular)
);
