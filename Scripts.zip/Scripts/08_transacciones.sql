-- 08_transacciones.sql
-- Idempotente: borra la procedure si existe y la crea
DROP PROCEDURE IF EXISTS actualizarSeguro;
DELIMITER $$

CREATE PROCEDURE actualizarSeguro(
    IN p_idVehiculo BIGINT,
    IN p_nuevoSeguro BIGINT
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'Error en la transacción. Se realizó rollback.' AS resultado;
    END;

    START TRANSACTION;

    -- Comprobar existencia del nuevo seguro: si no existe, lanzar error y disparar handler
    IF NOT EXISTS (SELECT 1 FROM SeguroVehicular WHERE id = p_nuevoSeguro) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Nuevo seguro no existe';
    END IF;

    -- Actualizaciones dentro de la transacción
    UPDATE Vehiculo
      SET seguro_id = p_nuevoSeguro
      WHERE id = p_idVehiculo;

    UPDATE SeguroVehicular
      SET cobertura = 'TODO_RIESGO'
      WHERE id = p_nuevoSeguro;

    COMMIT;
    SELECT 'Transacción realizada correctamente.' AS resultado;
END$$

DELIMITER ;
