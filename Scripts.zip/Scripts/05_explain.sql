-- 05_explain.sql
-- Análisis de rendimiento con EXPLAIN

-- Sin índices (ejecutar antes de crear los índices)
EXPLAIN SELECT v.dominio, v.marca, v.modelo, s.nroPoliza, s.cobertura
FROM Vehiculo v
JOIN SeguroVehicular s ON v.seguro_id = s.id
WHERE v.marca = 'Toyota' AND v.modelo = 'Corolla';

-- Con índices (ejecutar después de 04_indices.sql)
EXPLAIN SELECT v.dominio, v.marca, v.modelo, s.nroPoliza, s.cobertura
FROM Vehiculo v
JOIN SeguroVehicular s ON v.seguro_id = s.id
WHERE v.marca = 'Toyota' AND v.modelo = 'Corolla';
