-- 04_indices.sql
-- Creación de índices para optimización de consultas

-- Índice sobre el número de póliza, para búsqueda rápida por póliza
CREATE INDEX idx_poliza ON SeguroVehicular (nroPoliza);

-- Índice combinado por marca y modelo, para filtros frecuentes
CREATE INDEX idx_marca_modelo ON Vehiculo (marca, modelo);

-- Índice por año, para consultas de vehículos recientes
CREATE INDEX idx_anio ON Vehiculo (anio);
