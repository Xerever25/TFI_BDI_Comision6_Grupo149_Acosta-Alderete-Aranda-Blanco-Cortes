-- 02_catalogos.sql
-- Tablas de catálogo y carga inicial
-- Idempotente (DROP IF EXISTS + INSERT IGNORE)

-- Desactivar temporalmente FK
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS TipoCobertura;
DROP TABLE IF EXISTS Modelo;
DROP TABLE IF EXISTS Marca;

SET FOREIGN_KEY_CHECKS = 1;

-- 1️⃣ Catálogo de marcas
CREATE TABLE Marca (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2️⃣ Catálogo de modelos (relación 1:N con Marca)
CREATE TABLE Modelo (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL,
  marca_id BIGINT NOT NULL,
  CONSTRAINT fk_modelo_marca FOREIGN KEY (marca_id)
    REFERENCES Marca(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  UNIQUE (nombre, marca_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3️⃣ Catálogo de tipos de cobertura
CREATE TABLE TipoCobertura (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(30) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 🔹 Carga inicial de datos
INSERT IGNORE INTO Marca (nombre)
VALUES ('Toyota'), ('Ford'), ('Chevrolet'), ('Honda'), ('Fiat');

INSERT IGNORE INTO Modelo (nombre, marca_id)
SELECT 'Corolla', id FROM Marca WHERE nombre = 'Toyota'
UNION ALL
SELECT 'Yaris', id FROM Marca WHERE nombre = 'Toyota'
UNION ALL
SELECT 'Focus', id FROM Marca WHERE nombre = 'Ford'
UNION ALL
SELECT 'Fiesta', id FROM Marca WHERE nombre = 'Ford'
UNION ALL
SELECT 'Onix', id FROM Marca WHERE nombre = 'Chevrolet'
UNION ALL
SELECT 'Cruze', id FROM Marca WHERE nombre = 'Chevrolet'
UNION ALL
SELECT 'Civic', id FROM Marca WHERE nombre = 'Honda'
UNION ALL
SELECT 'City', id FROM Marca WHERE nombre = 'Honda'
UNION ALL
SELECT 'Cronos', id FROM Marca WHERE nombre = 'Fiat'
UNION ALL
SELECT 'Argo', id FROM Marca WHERE nombre = 'Fiat';

INSERT IGNORE INTO TipoCobertura (nombre)
VALUES ('RC'), ('TERCEROS'), ('TODO_RIESGO');
