-- 09_concurrencia_guiada.sql
-- Script idempotente para pruebas de concurrencia, deadlock y retry
-- Contiene:
-- 1) Creación de tabla PruebaDeadlock (InnoDB)
-- 2) Inserción inicial de filas de prueba
-- 3) Creación del procedimiento actualizarEstadoConRetry (retry ante deadlock)
-- 4) Instrucciones/giro paso a paso para reproducir deadlock en dos sesiones (A y B)
-- 5) Comandos útiles para diagnóstico (SHOW ENGINE INNODB STATUS, etc.)

/* =========================================================================
   1) Tabla de apoyo para pruebas de concurrencia / deadlock
   ========================================================================= */
DROP TABLE IF EXISTS PruebaDeadlock;

CREATE TABLE PruebaDeadlock (
    id INT PRIMARY KEY AUTO_INCREMENT,
    descripcion VARCHAR(100),
    estado VARCHAR(50)
) ENGINE=InnoDB;

-- Rellenar filas de prueba si no existen
INSERT INTO PruebaDeadlock (descripcion, estado)
SELECT 'Transacción 1', 'pendiente'
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM PruebaDeadlock WHERE id = 1);

INSERT INTO PruebaDeadlock (descripcion, estado)
SELECT 'Transacción 2', 'pendiente'
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM PruebaDeadlock WHERE id = 2);

-- Verificación rápida
SELECT * FROM PruebaDeadlock;

-- =========================================================================
-- 2) Procedimiento: actualizarEstadoConRetry
--    Intenta un UPDATE y reintenta ante deadlock (error 1213) hasta N intentos.
--    Idempotente: DROP PROCEDURE IF EXISTS + CREATE PROCEDURE
-- =========================================================================
DROP PROCEDURE IF EXISTS actualizarEstadoConRetry;
DELIMITER $$
CREATE PROCEDURE actualizarEstadoConRetry(
    IN p_id INT,
    IN p_estado VARCHAR(50)
)
BEGIN
    DECLARE v_intentos INT DEFAULT 0;
    DECLARE v_max INT DEFAULT 3; -- máximo reintentos
    DECLARE v_done INT DEFAULT 0;

    -- Handler para deadlock (1213): incrementa intentos y continúa
    DECLARE CONTINUE HANDLER FOR 1213
    BEGIN
        SET v_intentos = v_intentos + 1;
        -- Si excede max, marcamos terminado para informar luego
        IF v_intentos > v_max THEN
            SET v_done = 1;
        END IF;
        -- nota: el handler retorna control al flujo después del statement que causó el deadlock
    END;

    -- Handler para cualquier otra excepción: rollback y mensaje
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT CONCAT('SQL Exception. Se hizo ROLLBACK. Intentos: ', v_intentos) AS resultado;
    END;

    label_try: LOOP
        IF v_done = 1 THEN
            SELECT CONCAT('Error: deadlock persistente después de ', v_intentos, ' intentos.') AS resultado;
            LEAVE label_try;
        END IF;

        START TRANSACTION;
            UPDATE PruebaDeadlock SET estado = p_estado WHERE id = p_id;
        COMMIT;

        -- Si llegamos acá, commit fue exitoso
        IF v_intentos = 0 THEN
            SELECT 'Transacción completada con éxito.' AS resultado;
        ELSE
            SELECT CONCAT('Transacción completada con éxito tras ', v_intentos, ' reintentos.') AS resultado;
        END IF;
        LEAVE label_try;
    END LOOP label_try;
END$$
DELIMITER ;

-- Verificación de creación
SHOW PROCEDURE STATUS WHERE Db = DATABASE() AND Name = 'actualizarEstadoConRetry';

-- =========================================================================
-- 3) Guion paso a paso para reproducir deadlock (ejecutar manualmente en 2 sesiones)
--    -> Abrir DOS pestañas / conexiones a la misma base (Session A y Session B)
--    -> Seguir el orden exacto para provocar el deadlock
-- =========================================================================

/*
INSTRUCCIONES PARA REPRODUCIR DEADLOCK (MANUAL):

# Preparación (ejecutar en una sola sesión antes de empezar):
-- (opcional) limpiar estados previos
DELETE FROM PruebaDeadlock WHERE id NOT IN (1,2);
-- Asegurarse que filas 1 y 2 existen (si no, volver a insertar)
SELECT * FROM PruebaDeadlock;

# SESIÓN A (Pestaña A)
-- 1) Iniciar transacción y bloquear fila 1
START TRANSACTION;
UPDATE PruebaDeadlock SET estado = 'A_modificando' WHERE id = 1;
-- NO hacer COMMIT ni ROLLBACK aún: dejá la transacción abierta esperando

# SESIÓN B (Pestaña B)
-- 2) Iniciar transacción y bloquear fila 2
START TRANSACTION;
UPDATE PruebaDeadlock SET estado = 'B_modificando' WHERE id = 2;
-- NO hacer COMMIT ni ROLLBACK aún: dejá la transacción abierta esperando

# SESIÓN A (volver a A)
-- 3) A intenta bloquear fila 2: esto quedará en espera porque B la tiene bloqueada
UPDATE PruebaDeadlock SET estado = 'A_intenta' WHERE id = 2;
-- Esta instrucción quedará bloqueada esperando el lock de B

# SESIÓN B (volver a B)
-- 4) B intenta bloquear fila 1: conflicto -> deadlock
UPDATE PruebaDeadlock SET estado = 'B_intenta' WHERE id = 1;
-- En alguna de las dos sesiones MySQL abortará una transacción con:
-- ERROR 1213 (40001): Deadlock found when trying to get lock; try restarting transaction

# Tras el deadlock:
-- En la sesión que recibió el error, verás el mensaje 1213.
-- En la otra sesión, la transacción probablemente aún esté activa (completar o hacer ROLLBACK).
-- Puedes ejecutar SHOW ENGINE INNODB STATUS\G para más detalles del deadlock (en una sesión con permisos).
*/

-- =========================================================================
-- 4) Comandos útiles para diagnóstico (ejecutar en cualquier sesión con permisos)
-- =========================================================================
-- Mostrar el último estado de InnoDB (incluye detalle del deadlock)
-- Ejecutar inmediatamente después del deadlock para capturar información
-- Nota: el output es largo; tomá captura de pantalla del segmento relevante.
SHOW ENGINE INNODB STATUS\G;

-- Mostrar procesos/locks activos (útil para ver transacciones abiertas)
SELECT * FROM INFORMATION_SCHEMA.INNODB_TRX\G;
SELECT * FROM INFORMATION_SCHEMA.INNODB_LOCKS\G;
SELECT * FROM INFORMATION_SCHEMA.INNODB_LOCK_WAITS\G;

-- =========================================================================
-- 5) Ejemplo de uso del procedimiento con retry (para probar automáticamente)
--    Ejecutar en una sesión limpia:
--    CALL actualizarEstadoConRetry(1, 'finalizado');
-- =========================================================================

-- (NOTA) El script deja comentarios con el guion para que ejecutes las instrucciones
-- en dos pestañas. No intentes ejecutar los pasos A y B en un solo run: debes hacerlo manualmente
-- en sesiones distintas para provocar el deadlock.

-- =========================================================================
-- 6) Verificación final (estado de la tabla)
-- =========================================================================
SELECT * FROM PruebaDeadlock;
